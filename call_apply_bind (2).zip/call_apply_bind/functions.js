// function a(){

//     function b(){
//         console.log(myVar);
//     }
//     b();
// }


// var myVar =1;

// a();

// function greet(){
//     console.log('hi');
// }

// greet.lng = "hello";

// console.log(greet.lng);
// funcExp();
// var funcExp = function(){

//     console.log('hi');

// }

// funcExp();

// function a(b){
//     document.write(b.greet);
// }

// // a(1);

// a({greet:"hi"});

// function a(b){
//     b();
// }

// a(function(){
//     console.log('hi');
// })

// var a = "hello";



// function reveString(a){
//     var output = "";
// for( var i = a.length-1; i>=0; i--){
//      output += a[i];
// }
// return output;


// }

// reveString('hello');
// console.log(output);

// var newString = "";
// function reverseString(str) {

//     // console.log(str);
    
    
//     for (var i = str.length-1; i >= 0; i--) {
       
//         newString += str[i];
      
//     }
//     return newString;
  
    
// }

// reverseString("hello");
// document.write(newString);

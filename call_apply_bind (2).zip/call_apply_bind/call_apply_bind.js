//function.call(thisArg, arg1, arg2, ...)
//thisArg - Optional. 
//arg1, arg2 --optional


//Ex:1 The call() allows for a function/method belonging to one object to be assigned and called for a different object.
var person = {
    getSummary:  function(){

        return `${this.firstName} ${this.lastName}`;
    }
}

var person1 = {
    firstName: "bala",
    lastName: "sangala"
}

var person2 = {
    firstName: 'arun',
    lastName: "sangala"
}

var out = person.getSummary.call(person1);
var out2 = person.getSummary.call(person2);
console.log(out);

// Ex:2 The call() method can accept arguments:

var person = {
    fullName: function(city, country) {
        return this.firstName + " " + this.lastName + "," + city + "," + country;
    }
}
var person1 = {
    firstName:"John",
    lastName: "Doe",
}
var person2 = {
    firstName:"Mary",
    lastName: "Doe",
}
var x = person.fullName.call(person1, "Oslo", "Norway"); 
document.getElementById("demo").innerHTML = x; 


//Ex:3 // call() provides a new value of this to the function/method. With call, you can write a method once and then inherit it in another object, without having to rewrite the method for the new object.


var person1 = pers

function Product(name, price) {
    this.name = name;
    this.price = price;

    this.getSummary = function(){
        return `${ this.name } has ${this.price} has ${this.catogiry}`; 
    }

}

function Food(name, price, catogiry){
    Product.call(this, name, price);
    this.catogiry = catogiry;
}

function Toy( name, price) {
    Product.call(this, name, price);
    this.catogiry = "toy";
}


var chese = new Food('Chicken pizza', 240, "food");
var fun = new Toy("my toy", 150);



// console.log(chese);

// console.log(chese.catogiry);
// console.log(fun.catogiry);

console.log(fun.getSummary());
console.log(chese.getSummary());
// The call() method is a predefined JavaScript method.
// With call(), an object can use a method belonging to another object.
// Method Reuse
// With the call() method, you can write a method that can be used on different objects.


//apply() method

var person = {
    fullName: function() {
        return this.firstName + " " + this.lastName;
    }
}
var person1 = {
    firstName:"John",
    lastName: "Doe",
}

var person2 = {
    firstName:"Mary",
    lastName: "Doe",
}

var x = person.fullName.apply(person1); 
console.log(x);
var out2 = person.getSummary.apply(person2);
console.log(out2)

// The difference is:

// The call() method takes arguments separately.

// The apply() method takes arguments as an array.
var person = {
    fullName: function(city, country) {
        return this.firstName + " " + this.lastName + "," + city + "," + country;
    }
}
var person1 = {
    firstName:"John",
    lastName: "Doe",
}

var person2 = {
    firstName:"Mary",
    lastName: "Doe",
}


var x = person.fullName.apply(person1, ["Oslo", "Norway"]); 
document.getElementById("demo").innerHTML = x; 




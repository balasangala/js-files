//call back function
//Simply put: A callback is a function that is to be executed after another function has finished executing — hence the name ‘call back’ or higher-order functions.
//When a function simply accepts another function as an argument, this contained function is known as a callback function. 
// A JavaScript Callback Function is a function that is passed as a parameter to another JavaScript function, and the callback function is run inside of the function it was passed into
// JavaScript Callback Functions can be used synchronously or asynchronously

//Why do we need Callbacks?

function first(){
    console.log(1);
}
function second(){
    console.log(2);
}

first();//1
second();//2

//As you would expect, the function first is executed first, and the function second is executed second — logging the following to the console:

// All good so far.

// But what if function first contains some sort of code that can’t be executed immediately? For example, an API request where we have to send the request then wait for a response? To simulate this action, were going to use setTimeout which is a JavaScript function that calls a function after a set amount of time. We’ll delay our function for 500 milliseconds to simulate an API request. Our new code will look like this:

function first(){
    // Simulate a code delay
    setTimeout( function(){
      console.log(1);
    }, 500 );
  }
  function second(){
    console.log(2);
  }
  first();
  second();

// 2
// 1

// Even though we invoked the first() function first, we logged out the result of that function after the second() function.

// It’s not that JavaScript didn’t execute our functions in the order we wanted it to, it’s instead that JavaScript didn’t wait for a response from first() before moving on to execute second().

// So why show you this? Because you can’t just call one function after another and hope they execute in the right order. Callbacks are a way to make sure certain code doesn’t execute until other code has already finished execution.

// Create a Callback
// Alright, enough talk, lets create a callback!

function doHomework(subject, callback) {
    alert(`Starting my ${subject} homework.`);
    callback();
  }
  
  doHomework('math', function() {
    alert('Finished my homework');
  });


//   But callback functions don’t always have to be defined in our function call. They can be defined elsewhere in our code like this:

  function doHomework(subject, callback) {
    alert(`Starting my ${subject} homework.`);
    callback();
  }
  function alertFinished(){
    alert('Finished my homework');
  }
  doHomework('math', alertFinished);
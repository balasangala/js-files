// a;
// console.log(a);//Uncaught ReferenceError: a is not defined

// var b;
// console.log(b);//undefined

// function a(){
//     b;
//     console.log(b);
// }

// a();//Uncaught ReferenceError: b is not defined

// var x = "Hello \n World";
// console.log(x);

//numbers

// var x = "10" + "20";
// console.log(x);//1020

// var x = "10" + 20;
// console.log(x);//1020

// var x = 10 + "20";
// console.log(x);//1020

// var x = 10+20+"30";
// console.log(x);//3030

// var x = "10" + 20 + 30;
// console.log(x);//102330


//JavaScript will try to convert strings to numbers in all numeric operations:

// var x = 20 - "10";
// console.log(x);//10

// var x = "20" - 10;
// console.log(x);//10

// var x = "20" - "10";
// console.log(x);//10

// var x = "100";
// var y = "10";
// var z = x + y;       // z will not be 110 (It will be 10010)

// var x = "100";
// var y = "10";
// var z = x/y;
// console.log(z);//10


// var x = "100";
// var y = "10";
// var z = x * y; 
// console.log(z);      // z will be 1000

// var x = "100";
// var y = "10";
// var z = x * y;       // z will be 1000

// var x = "100";
// var y = "10";
// var z = x - y;       // z will be 90


// var x = 100 / "Apple"; 
// console.log(x); // x will be NaN (Not a Number)

// var x = 100 / "10";   
// console.log(x); // x will be 10

// var x = 100 / "Apple";
// isNaN(x);               // returns true because x is Not a Number

// var x = NaN;
// var y = 5;
// var z = x + y;         // z will be NaN

// var x = NaN;
// var y = "5";
// var z = x + y;         // z will be NaN5

// typeof NaN;            // returns "number"


// var x =  2 / 0;          // x will be Infinity
// var y = -2 / 0;          // y will be -Infinity

// typeof Infinity;        // returns "number"

